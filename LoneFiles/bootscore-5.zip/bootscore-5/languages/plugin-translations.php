
<?php _e('All','bootscore'); ?>
<?php _e('Look what I found: ','bootscore'); ?>
<?php esc_html_e('Cookies help us deliver our services. By using our services, you agree to our use of cookies.', 'bootscore'); ?>
<?php esc_html_e('/privacy-policy', 'bootscore'); ?>
<?php esc_html_e('More Information', 'bootscore'); ?>
<?php esc_html_e('Accept', 'bootscore'); ?>		
